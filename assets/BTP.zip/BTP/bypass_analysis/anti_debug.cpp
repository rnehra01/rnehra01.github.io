#include <stdio.h>
#include "Windows.h"
#include "winable.h"
#include <ctime>

//Detect debugger using win native function
BOOL check_local_debugger(){
  if(IsDebuggerPresent()){
	return TRUE;
  }
  return FALSE;
}

BOOL check_remote_debugger(){
  BOOL debugger = FALSE;
  HANDLE proc = GetCurrentProcess();

  CheckRemoteDebuggerPresent(proc, &debugger);
  return debugger;
}

BOOL check_debug_port() {
  typedef int (WINAPI * pNtQueryInformationProcess)
  (HANDLE, UINT, PVOID, ULONG, PULONG);

  DWORD port = 0;
  int status;

  pNtQueryInformationProcess NtQIP = (pNtQueryInformationProcess)GetProcAddress(
  										GetModuleHandle(TEXT("ntdll.dll")),
  										"NtQueryInformationProcess");
  //https://docs.microsoft.com/en-us/windows/desktop/api/winternl/nf-winternl-ntqueryinformationprocess#parameters
  status = NtQIP(GetCurrentProcess(), 0x07, &port, sizeof(port), NULL);

  return port;
}

BOOL check_systemkernel_debuggerRt(){
	typedef long NTSTATUS; 
    #define STATUS_SUCCESS    ((NTSTATUS)0L) 
    HANDLE hProcess = GetCurrentProcess();

    typedef struct _SYSTEM_KERNEL_DEBUGGER_INFORMATION { 
                 BOOLEAN DebuggerEnabled; 
                 BOOLEAN DebuggerNotPresent; 
    } SYSTEM_KERNEL_DEBUGGER_INFORMATION, *PSYSTEM_KERNEL_DEBUGGER_INFORMATION; 

    enum SYSTEM_INFORMATION_CLASS { SystemKernelDebuggerInformation = 35 }; 

    typedef NTSTATUS  (__stdcall *ZW_QUERY_SYSTEM_INFORMATION)(IN SYSTEM_INFORMATION_CLASS SystemInformationClass, IN OUT PVOID SystemInformation, IN ULONG SystemInformationLength, OUT PULONG ReturnLength); 

	ZW_QUERY_SYSTEM_INFORMATION ZwQuerySystemInformation;
    SYSTEM_KERNEL_DEBUGGER_INFORMATION Info;
    HMODULE hModule = GetModuleHandle("ntdll.dll");

    ZwQuerySystemInformation = (ZW_QUERY_SYSTEM_INFORMATION)GetProcAddress(hModule, "ZwQuerySystemInformation");
    if (ZwQuerySystemInformation) {
        if (STATUS_SUCCESS == ZwQuerySystemInformation(SystemKernelDebuggerInformation, &Info, sizeof(Info), NULL)) {
            if (Info.DebuggerEnabled&&!Info.DebuggerNotPresent) {
                return TRUE;
            }
        }
    }
    return FALSE;
}

BOOL check_outputdebugstring() {
	OutputDebugStringA("Debug this\n");
	if (GetLastError() == 0)
	  return FALSE;
	else return TRUE;
}

int check_guard_page(){
	SYSTEM_INFO sSysInfo;
	GetSystemInfo(&sSysInfo);
	DWORD dwPageSize = sSysInfo.dwPageSize;

	LPVOID lpvAddr = VirtualAlloc(NULL, dwPageSize, MEM_COMMIT , PAGE_EXECUTE_READWRITE);
	if (lpvAddr == NULL) {
		return 1;
	}
	DWORD dwOldProtect;
	BOOL vprotect = VirtualProtect(lpvAddr, dwPageSize, PAGE_EXECUTE_READWRITE | PAGE_GUARD, &dwOldProtect);
	if (!vprotect) {
		return 1;
	} else {
		// PAGE_GUARD Achieved
		return 0;
	}
}

BOOL time_based_check(){
    SYSTEMTIME sst, send;
	FILETIME fst, fend;
	GetSystemTime(&sst);
	GetSystemTime(&send);
	SystemTimeToFileTime(&sst, &fst);
	SystemTimeToFileTime(&send, &fend);
	if (((fst.dwHighDateTime - fend.dwHighDateTime) > 10) || ((fst.dwLowDateTime - fend.dwLowDateTime) > 10))
	  return TRUE;

	GetLocalTime(&sst);
	GetLocalTime(&send);
	SystemTimeToFileTime(&sst, &fst);
	SystemTimeToFileTime(&send, &fend);
	if (((fst.dwHighDateTime - fend.dwHighDateTime) > 10) || ((fst.dwLowDateTime - fend.dwLowDateTime) > 10))
	  return TRUE;
		return FALSE;
	
}

//make debugging harder
BOOL switch_desktop() {
	BOOL res = FALSE;

	HDESK new_desktop = CreateDesktop(("newdesktop"), NULL, NULL, 0,
		DESKTOP_CREATEWINDOW | DESKTOP_WRITEOBJECTS | DESKTOP_SWITCHDESKTOP,
		NULL);
	if (!new_desktop)
		res = SwitchDesktop(new_desktop);
			if (res)
			    return TRUE;
			else
			    return FALSE;
}

void self_debug() {
	STARTUPINFO sinfo;
	PROCESS_INFORMATION pinfo;

	ZeroMemory( &sinfo, sizeof(sinfo) );
	sinfo.cb = sizeof(sinfo);
	sinfo.dwFlags = 0x1;
	sinfo.wShowWindow = 0x0;
	ZeroMemory( &pinfo, sizeof(pinfo) );

	if (CreateProcess("C:\\windows\\system32\\calc.exe",
		NULL, NULL, NULL, FALSE,
		DEBUG_PROCESS, NULL, NULL,
		&sinfo, &pinfo )){
		ContinueDebugEvent(pinfo.dwProcessId, pinfo.dwThreadId, DBG_CONTINUE);
		WaitForSingleObject(pinfo.hProcess, INFINITE);
		CloseHandle(pinfo.hProcess);
		CloseHandle(pinfo.hThread);
	}
}

void block_mouse_keyboard_input() {
	BlockInput(TRUE);
	// Do malware work;
	// Unblock BlockInput(FALSE);
}

void disable_delievery_of_debug_events(){
    typedef NTSTATUS (NTAPI *pfnNtSetInformationThread)(
    _In_ HANDLE ThreadHandle,
    _In_ ULONG  ThreadInformationClass,
    _In_ PVOID  ThreadInformation,
    _In_ ULONG  ThreadInformationLength
    );
    const ULONG ThreadHideFromDebugger = 0x11;
	pfnNtSetInformationThread NtSetInformationThread = (pfnNtSetInformationThread)
        GetProcAddress(GetModuleHandle("ntdll.dll"), "NtSetInformationThread");
	NTSTATUS ntStatus  = NtSetInformationThread(GetCurrentThread(),ThreadHideFromDebugger,NULL,0);
}

void new_self_process() {
	HANDLE mutex = NULL;
	STARTUPINFO sinfo;
	PROCESS_INFORMATION pinfo;

	ZeroMemory( &sinfo, sizeof(sinfo) );
	sinfo.cb = sizeof(sinfo);
	sinfo.dwFlags = 0x1;
	sinfo.wShowWindow = 0x0;
	ZeroMemory( &pinfo, sizeof(pinfo) );

	mutex = CreateMutex(NULL, FALSE, TEXT("anti_debug_mutex"));
	if (mutex != NULL)
		if (GetLastError() != ERROR_ALREADY_EXISTS) {
		  if ( !CreateProcess( "C:\\windows\\system32\\calc.exe", //replace your process here
						NULL,
						NULL,
						NULL,
						FALSE,
						CREATE_NEW_CONSOLE,
						NULL,
						NULL,
						&sinfo,
						&pinfo )) {
				printf("ERROR CreateProcess failed (%d).\n", GetLastError());
			} else {
				//Do malicious work
				WaitForSingleObject(pinfo.hProcess, INFINITE);
				ExitProcess(0);
			}
	}
}

void escape_from_breakpoint() {
	DWORD dw_old_protect;
	unsigned char* dbg_breakpoint=(unsigned char*)GetProcAddress(
		GetModuleHandle(("ntdll.dll") ), "dbg_breakpoint");
	VirtualProtect(dbg_breakpoint, 1,
		PAGE_EXECUTE_READWRITE, &dw_old_protect);
	*dbg_breakpoint = 0x90;
}

int main(){
  BOOL check = check_debug_port();
  // switch_desktop();
  // printf(check);
  int ch = check_guard_page();
    check = check_outputdebugstring();
	escape_from_breakpoint();
  if(ch==0){
	printf("[-] Fall back\n");
  }else{
	printf("[+] Attack\n");
  }
}


