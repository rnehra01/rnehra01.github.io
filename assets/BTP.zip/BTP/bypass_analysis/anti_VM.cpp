#include <stdio.h>
#include <tchar.h>
#include <Windows.h>
#include <conio.h>
#include <excpt.h>
#include <tlhelp32.h>

//VM detection using characteristic functions
bool detect_using_sidt(){
    //using sidt
    unsigned char idtr[6];
	asm("sidt %0\n" : :"m"(idtr));
	unsigned long idt = *((unsigned long *)&idtr[2]);
	if 	((idt >> 24) == 0xff)
	  return 1;

    //using sldt
	unsigned char ldtr[5] = "\xef\xbe\xad\xde";
	asm("sldt %0\n" : :"m"(ldtr));
	unsigned long ldt = *((unsigned long *)&ldtr[0]);
	if (ldt != 0xdead0000)
	  return 1;

	//using gdtr
	unsigned char gdtr[6];
	asm("sgdt %0\n" : :"m"(gdtr));
	unsigned long gdt = *((unsigned long *)&gdtr[2]);
	if ((gdt >> 24) == 0xff)
	  return 1;

	// using str
	unsigned char mem[4] = {0, 0, 0, 0};
	asm("str %0\n" : :"m"(mem));
	if ((mem[0] == 0x00) && (mem[1] == 0x40))
	  return 1;

	//using smsw
	unsigned int reax = 0;
	asm(
		"mov $0xcccccccc, %%eax;"
		"smsw %%eax;"
		"mov %%eax, %0;"
		:"=r"(reax)
		:
		:"%eax"
		);

	if ( (( (reax >> 24) & 0xFF ) == 0xcc) && (( (reax >> 16) & 0xFF ) == 0xcc))
	  return 1;

	return 0;
}

bool detect_vmware_using_port(){
    unsigned int open = 0;
	try{
	  asm(
		  "mov $0x564d5868, %%eax;" // 'VMXh'
		  "mov $0x5658, %%edx;"		// 'VX(port)'
		  "in %%dx, %%eax;"
		  "mov %%eax, %0;"
		  :"=r" (open)
		  :
		  :"%eax", "%edx"
		  );
	}catch (...) { }

	if(open > 0)
	  return 1;
	return 0;
}

// https://www.cyberbit.com/blog/endpoint-security/anti-vm-and-anti-sandbox-explained/
bool detect_brand(){
  unsigned char brand[20];
  asm("mov $0x40000000, %%eax;"
	  "cpuid;"
	  "mov %%eax, %0;"
	  :"=m"(brand)
	  :
	  :"%eax");
  printf("%s", brand);
  unsigned char vmware_brand[20] = "VMwareVMware";
  unsigned char MS_brand[20] = "Microsoft HV";
  if(brand==vmware_brand || brand==MS_brand)
	return 1;
  return 0;
}

// https://www.cyberbit.com/blog/endpoint-security/anti-vm-and-anti-sandbox-explained/
int detect_using_characteristic_processes(){
	PROCESSENTRY32 pe32;
	TCHAR VMWARE_PROCESSES[][20] = {TEXT("Vmtoolsd.exe"), TEXT("Vmwaretrat.exe"), TEXT("Vmwareuser.exe"), TEXT("Vmacthlp.exe")};
	TCHAR VIRTUALBOX_PROCESSES[][20] = {TEXT("vboxservice.exe"), TEXT("vboxtray.exe")};
	
	HANDLE SYSTEM_PROCESSES = CreateToolhelp32Snapshot( TH32CS_SNAPPROCESS, 0 );
	if( SYSTEM_PROCESSES == INVALID_HANDLE_VALUE ) {
		printf("ERROR: call CreateToolhelp32Snapshot\n");
		CloseHandle( SYSTEM_PROCESSES );
		return 2;
	}

	pe32.dwSize = sizeof( PROCESSENTRY32 );

	if( !Process32First( SYSTEM_PROCESSES, &pe32 ) ) {
		printf("ERROR: call Process32First\n");
		CloseHandle (SYSTEM_PROCESSES);
		return 0;
	}

	do {
	  for(int i=0; i<4; i++)
		if (_tcscmp(pe32.szExeFile, VMWARE_PROCESSES[i]) == 0) {// found explorer.exe
		  printf("Found Process %s with PID: %d", VMWARE_PROCESSES[i], pe32.th32ProcessID);
		  return 0;
		}

	  for(int i=0; i<2; i++)
		if (_tcscmp(pe32.szExeFile, VIRTUALBOX_PROCESSES[i]) == 0) {// found explorer.exe
		  printf("Found Process %s with PID: %d", VIRTUALBOX_PROCESSES[i], pe32.th32ProcessID);
		  return 1;
		}

	} while ( Process32Next(SYSTEM_PROCESSES, &pe32));

	CloseHandle( SYSTEM_PROCESSES );
	return 0;

}

// https://www.cyberbit.com/blog/endpoint-security/anti-vm-and-anti-sandbox-explained/
bool detect_using_characteristic_files(){
   WIN32_FIND_DATA ffd;
   LARGE_INTEGER filesize;
   TCHAR VMWARE_DIR[40] = TEXT("C:\\windows\\System32\\Drivers\\*");
   TCHAR VMWARE_FILES[][20] = {TEXT("Vmmouse.sys"), TEXT("vm3dgl.dll"), TEXT("vmdum.dll"), TEXT("vm3dver.dll"), TEXT("vmtray.dll"), TEXT("VMToolsHook.dll"), TEXT("vmmousever.dll"), TEXT("vmhgfs.dll"), TEXT("vmGuestLib.dll"), TEXT("VmGuestLibJava.dll")};

   TCHAR VIRTUALBOX_DIR[40] = TEXT("C:\\windows\\System32\\*");
   TCHAR VIRTUALBOX_FILES[][40] = { TEXT("vboxdisp.dll"), TEXT("vboxhook.dll"), TEXT("vboxmrxnp.dll"), TEXT("vboxogl.dll"), TEXT("vboxoglarrayspu.dll"), TEXT("vboxoglcrutil.dll"), TEXT("vboxoglerrorspu.dll"), TEXT("vboxoglfeedbackspu.dll"), TEXT("vboxoglpackspu.dll"), TEXT("vboxoglpassthroughspu.dll"), TEXT("vboxservice.exe"), TEXT("vboxtray.exe"), TEXT("VBoxControl.exe")};
   
   HANDLE hFind = INVALID_HANDLE_VALUE;
   DWORD dwError=0;

   hFind = FindFirstFile(VMWARE_DIR, &ffd);

   if (INVALID_HANDLE_VALUE == hFind){
      return 0;
   } 

   do{
	 if (!(ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)){ //not a directory
	   for(int i=0; i<10; i++){
		 if(_tcscmp(ffd.cFileName, VMWARE_FILES[i]) == 0)
		   return 1;
	   } 
      }      
   }
   while (FindNextFile(hFind, &ffd) != 0);

   hFind = FindFirstFile(VIRTUALBOX_DIR, &ffd);

   if (INVALID_HANDLE_VALUE == hFind){
      return 0;
   } 

   do{
	 if (!(ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)){ //not a directory
	   for(int i=0; i<10; i++){
		 if(_tcscmp(ffd.cFileName, VIRTUALBOX_FILES[i]) == 0)
		   return 1;
	   } 
      }      
   }
   while (FindNextFile(hFind, &ffd) != 0);  

   FindClose(hFind);
   return 0;
}

int main(){
  bool check = detect_brand();
  check = detect_using_characteristic_processes();
  if(check)
	printf("[-] Detected");
}
