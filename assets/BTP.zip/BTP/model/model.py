from keras.layers import Input, Dense, Activation
from keras.layers.merge import Maximum, Concatenate
from keras.models import Model
from keras.optimizers import Adam

from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn import linear_model, svm, tree
from sklearn.model_selection import train_test_split
from sklearn.ensemble import AdaBoostClassifier
from rr_forest import RRForestClassifier
import matplotlib.pyplot as plt
import numpy as np

import sys
import warnings

class AdMal():
    def __init__(self, bbox, filename='data.npz'):
        self.gen_layers = [128+20, 256, 128] # api_vector, hidden, output_api_vector
        self.subs_detector_layers = [128, 256, 1]
        self.bbox = bbox       
        optimizer = Adam(lr=0.001)
        self.filename = filename

        # Build and Train blackbox_detector
        self.bbox_detector = self.get_bbox_detector()

        # Build and compile the substitute_detector
        self.subs_detector = self.get_subs_detector()
        self.subs_detector.compile(loss='binary_crossentropy', optimizer=optimizer, metrics=['accuracy'])

        # Build the generator
        self.gen = self.get_gen()

        # The generator takes malware and noise as input and generates adversarial malware examples
        example = Input(shape=(128,))
        noise = Input(shape=(20,))
        input = [example, noise]
        malware_examples = self.gen(input)

        # For the combined model we will only train the generator
        self.subs_detector.trainable = False

        # The discriminator takes generated images as input and determines validity
        validity = self.subs_detector(malware_examples)

        # The combined model  (stacked generator and substitute_detector)
        # Trains the generator to fool the discriminator
        self.combined = Model(input, validity)
        self.combined.compile(loss='binary_crossentropy', optimizer=optimizer)

    def get_bbox_detector(self):
        if self.bbox is 'RF':
            bbox_detector = RandomForestClassifier(n_estimators=100, max_depth=3, random_state=1)
        elif self.bbox is 'RRF':            
            bbox_detector = RRForestClassifier(n_estimators=100, max_depth=3, random_state=1)
        elif self.bbox is 'ARF':            
            rf = RandomForestClassifier(n_estimators=100, max_depth=3, random_state=1)
            bbox_detector = AdaBoostClassifier(n_estimators=50, base_estimator=rf, learning_rate=1)
        elif self.bbox is 'SVM':
            bbox_detector = svm.SVC()
        elif self.bbox is 'LR':
            bbox_detector = linear_model.LogisticRegression()

        return bbox_detector

    def get_gen(self):

        example = Input(shape=(128,))
        noise = Input(shape=(20,))
        x = Concatenate(axis=1)([example, noise])
        for dim in self.gen_layers[1:]:
            x = Dense(dim)(x)
        x = Activation(activation='sigmoid')(x)
        x = Maximum()([example, x])
        gen = Model([example, noise], x, name='gen')
        gen.summary()
        return gen

    def get_subs_detector(self):

        input = Input(shape=(self.subs_detector_layers[0],))
        x = input
        for dim in self.subs_detector_layers[1:]:
            x = Dense(dim)(x)
        x = Activation(activation='sigmoid')(x)
        subs_detector = Model(input, x, name='subs_detector')
        subs_detector.summary()
        return subs_detector

    def load_data(self):

        data = np.load(self.filename)
        xmal, ymal, xben, yben = data['xmal'], data['ymal'], data['xben'], data['yben']
        return (xmal, ymal), (xben, yben)

    def train(self, epochs, batch_size=32, is_first=1):

        # Load and Split the dataset
        (xmal, ymal), (xben, yben) = self.load_data()
        xtrain_mal, xtest_mal, ytrain_mal, ytest_mal = train_test_split(xmal, ymal, test_size=0.20)
        xtrain_ben, xtest_ben, ytrain_ben, ytest_ben = train_test_split(xben, yben, test_size=0.20)
        bl_xtrain_mal, bl_ytrain_mal, bl_xtrain_ben, bl_ytrain_ben = xtrain_mal, ytrain_mal, xtrain_ben, ytrain_ben

        # if is_first is Ture, Train the blackbox_detctor
        if is_first:
            self.bbox_detector.fit(np.concatenate([xmal, xben]),
                                       np.concatenate([ymal, yben]))

        ytrain_ben_bbox = self.bbox_detector.predict(bl_xtrain_ben)
        Original_Train_TPR = self.bbox_detector.score(bl_xtrain_mal, bl_ytrain_mal)
        Original_Test_TPR = self.bbox_detector.score(xtest_mal, ytest_mal)
        Train_TPR, Test_TPR = [Original_Train_TPR], [Original_Test_TPR]
        best_TPR = 1.0
        for epoch in range(epochs):

            for step in range(xtrain_mal.shape[0] // batch_size):
                # ---------------------
                #  Train substitute_detector
                # ---------------------

                # Select a random batch of malware examples
                idx = np.random.randint(0, xtrain_mal.shape[0], batch_size)
                xmal_batch = xtrain_mal[idx]
                noise = np.random.uniform(0, 1, (batch_size, 20))
                idx = np.random.randint(0, xmal_batch.shape[0], batch_size)
                xben_batch = xtrain_ben[idx]
                yben_batch = ytrain_ben_bbox[idx]

                # Generate a batch of new malware examples
                gen_examples = self.gen.predict([xmal_batch, noise])
                ymal_batch = self.bbox_detector.predict(np.ones(gen_examples.shape)*(gen_examples > 0.5))

                # Train the substitute_detector
                d_loss_real = self.subs_detector.train_on_batch(gen_examples, ymal_batch)
                d_loss_fake = self.subs_detector.train_on_batch(xben_batch, yben_batch)
                d_loss = 0.5 * np.add(d_loss_real, d_loss_fake)

                # ---------------------
                #  Train Generator
                # ---------------------

                idx = np.random.randint(0, xtrain_mal.shape[0], batch_size)
                xmal_batch = xtrain_mal[idx]
                noise = np.random.uniform(0, 1, (batch_size, 20))

                # Train the generator
                g_loss = self.combined.train_on_batch([xmal_batch, noise], np.zeros((batch_size, 1)))

            # Compute Train TPR
            noise = np.random.uniform(0, 1, (xtrain_mal.shape[0], 20))
            gen_examples = self.gen.predict([xtrain_mal, noise])
            TPR = self.bbox_detector.score(np.ones(gen_examples.shape) * (gen_examples > 0.5), ytrain_mal)
            Train_TPR.append(TPR)

            # Compute Test TPR
            noise = np.random.uniform(0, 1, (xtest_mal.shape[0], 20))
            gen_examples = self.gen.predict([xtest_mal, noise])
            TPR = self.bbox_detector.score(np.ones(gen_examples.shape) * (gen_examples > 0.5), ytest_mal)
            Test_TPR.append(TPR)

            # Save best model
            if TPR < best_TPR:
                self.combined.save_weights('saves/model_{0}.weights'.format(self.bbox))
                best_TPR = TPR

            # Plot the progress
            if is_first:
                print("%d [D loss: %f, acc.: %.2f%%] [G loss: %f]" % (epoch, d_loss[0], 100*d_loss[1], g_loss))

        print('\n\nBlackBox: {0}'.format(self.bbox))
        print('\nOriginal_Train_TPR: {0}, Adver_Train_TPR: {1}'.format(Original_Train_TPR, Train_TPR[-1]))
        print('\nOriginal_Test_TPR: {0}, Adver_Test_TPR: {1}'.format(Original_Test_TPR, Test_TPR[-1]))

        # Plot TPR
        # plt.figure()
        # plt.plot(range(len(Train_TPR)), Train_TPR, c='r', label='Training Set', linewidth=2)
        # plt.plot(range(len(Test_TPR)), Test_TPR, c='g', linestyle='--', label='Validation Set', linewidth=2)
        # plt.xlabel('Epoch')
        # plt.ylabel('TPR')
        # plt.legend()
        # plt.savefig('saves/Epoch_TPR({0}).png'.format(self.bbox))
        # plt.show()

if __name__ == '__main__':
    warnings.simplefilter("ignore")
    admal = AdMal(bbox='SVM')
    admal.train(epochs=200, batch_size=64)
